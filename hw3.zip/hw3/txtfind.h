#ifndef _txtfind_h_
#define _txtfind_h_

int Getline(char []);
int getword(char []);
int substring(char*, char*);
int similar(char*, char*, int);
void print_lines(char*);
void print_similar_words(char*);

#endif
