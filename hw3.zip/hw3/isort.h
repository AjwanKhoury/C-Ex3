#ifndef _SORTING_H_
#define _SORTING_H_
void shift_element(int *arr, int n);
void help(int *arr,int len);
void insertion_sort(int *arr , int len);
#endif
